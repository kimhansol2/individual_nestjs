import {
  Controller,
  Get,
  Query,
  Res,
  Req,
  Post,
  UnauthorizedException,
  HttpCode,
} from '@nestjs/common';
import type { Response, Request } from 'express';
import { SteamOpenIdService } from './steam-openid.service';

function getCookie(req: Request, name: string): string | undefined {
  const anyReq = req as unknown as { cookies?: unknown };
  const { cookies } = anyReq;
  if (cookies && typeof cookies === 'object') {
    const val = (cookies as Record<string, unknown>)[name];
    if (typeof val === 'string') return val;
  }
  return undefined;
}

@Controller('auth/steam')
export class SteamAuthController {
  constructor(private readonly steam: SteamOpenIdService) {}

  // 스팀 로그인 페이지로 리다이렉트
  @Get()
  async start(@Res() res: Response) {
    const url = await this.steam.buildRedirectUrl();
    return res.redirect(url);
  }

  @Get('callback')
  async callback(
    @Query() query: Record<string, string>,
    @Res({ passthrough: true }) res: Response,
  ) {
    const result = await this.steam.finalizeLogin(query);

    // refersh 쿠키 설정 (HttpOnly)
    res.cookie('refresh_token', result.refreshToken, {
      httpOnly: true,
      secure: false, // 바꿔야함
      sameSite: 'lax',
      maxAge: result.refreshTokenMaxAgeMs,
      path: '/api/v1',
    });

    // body에는 accessToken만
    return {
      tokenType: 'Bearer',
      accessToken: result.accessToken,
      expiresIn: result.accessTokenExpiresIn,
      user: result.user,
    };
  }

  @Post('refresh')
  @HttpCode(200)
  async refresh(
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ) {
    const token = getCookie(req, 'refresh_token');
    if (!token) throw new UnauthorizedException('no refresh cookie');

    const out = await this.steam.rotateRefreshToken(token);

    res.cookie('refresh_token', out.refreshToken, {
      httpOnly: true,
      secure: false, // 바꿔야함
      sameSite: 'lax',
      maxAge: out.refreshTokenMaxAgeMs,
      path: '/api/v1',
    });

    return {
      tokenType: 'Bearer',
      accessToken: out.accessToken,
    };
  }
}
